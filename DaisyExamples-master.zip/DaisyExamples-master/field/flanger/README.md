# Flanger Example

## Author

Ben Sergentanis

## Description

Flanger efffect for Daisy Field.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/field/flanger)

## Controls

| Control | Description |
| --- | --- |
| SW 1 |  Effect On/Off |
| Knob 1 | Delay Time |
| Knob 2 | Feedback Amount |
| Knob 3 | Lfo Frequency |
| Knob 4 | Lfo Depth |
