# Versio

Examples for the Noise Engineering Versio platform.

## Features

- Stereo Audio Input
- Stereo Audio Output
- 7x Knobs
- 7x CVs
- 2x 3-position toggles
- 1x button
- 4x RGB LEDs

