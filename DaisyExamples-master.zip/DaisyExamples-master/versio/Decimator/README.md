# Decimator

## Author

Ankoor Apte, Noise Engineering

## Description

Decimator example for the Versio

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/versio/Decimator)

## Controls

All controls have some effect on the LEDs

| Control | Description |
| --- | --- |
| Knob 0 | Bitcrush factor (left) |
| Knob 1 | Downsample factor (left) |
| Knob 2 | Bitcrush factor (right) |
| Knob 3 | Downsample factor (right) |


## Demo 

TODO: Add demo
