#!/bin/bash

./ci/build_libs.sh
./ci/build_examples.py

echo "finished"

