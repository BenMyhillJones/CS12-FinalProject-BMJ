# Blink

## Author

Shensley

## Description

Blinks the Seed's onboard LED at a constant rate.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/seed/Blink)
