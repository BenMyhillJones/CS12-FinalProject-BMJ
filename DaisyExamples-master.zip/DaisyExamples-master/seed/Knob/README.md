# Knob

## Author

Shensley


## Description

Using a knob to control the brightness of an led.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/seed/Knob)

## Breadboard

<img src="https://raw.githubusercontent.com/electro-smith/DaisyExamples/master/seed/Knob/resources/Knob_bb.png" alt="SeedKnob_bb.png" style="width: 100%;"/>

## Schematic  

<img src="https://raw.githubusercontent.com/electro-smith/DaisyExamples/master/seed/Knob/resources/Knob_schem.png" alt="SeedKnob_schem.png" style="width: 100%;"/>
