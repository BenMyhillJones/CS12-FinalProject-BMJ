# QSPI

This project provides a simple example of writing and reading from QSPI. If the writes and reads are successful, then you should see a slowly blinking LED and hear a saw wave. If there's an issue, the LED will blink a bit faster. 