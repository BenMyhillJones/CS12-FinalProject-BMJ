# StringVoice Example

## Author

Ben Sergentanis

## Description

Demonstrates StringVoice with modulated parameters.