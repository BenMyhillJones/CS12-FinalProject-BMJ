# Flanger Example

## Author

Ben Sergentanis

## Description

Demonstrates flanger with Oscillator patch.