# SyntheticSnareDrum Example

## Author

Ben Sergentanis

## Description

Demonstrates the SyntheticSnareDrum by randomly modulating parameters.