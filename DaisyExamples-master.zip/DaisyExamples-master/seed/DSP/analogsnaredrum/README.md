# AnalogSnareDrum Example

## Author

Ben Sergentanis

## Description

Demonstrates AnalogSnareDrum with randomized parameters.