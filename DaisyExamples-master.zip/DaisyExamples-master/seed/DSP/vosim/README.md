# Vosim Oscillator Example

Demonstrates Vosim (Voice Simulation) Oscillator by sweeping formant.

## Author

Ben Sergentanis