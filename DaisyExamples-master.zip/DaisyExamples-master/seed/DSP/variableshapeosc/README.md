# Variable Shape Oscillator Example

Demonstrates Variable Shape Oscillator by sweeping pulse width, sync frequency, and waveshape.

## Author 

Ben Sergentanis
