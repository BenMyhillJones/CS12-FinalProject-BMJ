# Harmonic Oscillator Example

Plays a scale, sweeping through the harmonics on every note.

## Author

Ben Sergentanis

