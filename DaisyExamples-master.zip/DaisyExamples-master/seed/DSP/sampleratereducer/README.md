# SampleRateReducer Example

## Author

Ben Sergentanis

## Description

Demonstrates the SampleRateReducer on a sine wave sweeping through the rates.