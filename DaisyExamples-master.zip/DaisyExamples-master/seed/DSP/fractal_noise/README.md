# FractalNoiseGenerator Example

## Author

Ben Sergentanis

## Description

Demonstrates FractalNoiseGenerator by modulating Color and Freq.