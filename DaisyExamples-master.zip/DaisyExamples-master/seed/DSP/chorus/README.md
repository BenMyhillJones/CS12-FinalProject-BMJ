# Chorus Example

## Author

Ben Sergentanis

## Description

Demonstrates chorus effect on drum pattern.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/seed/chorus)
