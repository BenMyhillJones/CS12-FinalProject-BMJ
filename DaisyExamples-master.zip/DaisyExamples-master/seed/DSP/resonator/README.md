# Resonator Module Example

## Author

Ben Sergentanis

## Description

Demonstrates the resonator module by striking it with random values for the parameters.
