# Overdrive Module Example

## Author

Ben Sergentanis

## Description

Demonstrates DaisySP Overdrive module by clipping a sine wave by different amounts.
