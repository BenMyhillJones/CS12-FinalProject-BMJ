# Clocked Noise Example

## Author

Ben Sergentanis

## Description

Demonstrates ClockedNoise module by generating different frequencies of clocked noise.