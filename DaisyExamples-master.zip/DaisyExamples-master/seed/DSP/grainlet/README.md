# Grainlet Oscillator Example

Plays a sequence while sweeping the grainlet osc's shape and formant freq parameters.

## Author

Ben Sergentanis