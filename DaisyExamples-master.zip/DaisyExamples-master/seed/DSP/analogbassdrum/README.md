# AnalogBassDrum Example

## Author

Ben Sergentanis

## Description

Demonstrates AnalogBassDrum with randomized parameters.