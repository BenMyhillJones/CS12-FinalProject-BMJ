# HiHat Module Example

## Author

Ben Sergentanis

## Description

Demonstrates HiHat Module with randomized parameters.