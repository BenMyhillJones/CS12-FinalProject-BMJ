# SyntheticBassDrum Example

## Author

Ben Sergentanis

## Description

Demonstrates SyntheticBassDrum module by modulating parameters.