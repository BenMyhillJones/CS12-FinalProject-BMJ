# ZOscillator Example

Demonstrates ZOscillator by sweeping formant and mode.

## Author

Ben Sergentanis
