# Particle Module Example

## Author

Ben Sergentanis

## Description

Demonstrates Particle module, lfo over density parameter.