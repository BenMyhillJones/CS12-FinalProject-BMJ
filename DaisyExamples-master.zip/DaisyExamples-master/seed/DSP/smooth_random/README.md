# SmoothRandomGenerator Module Example

## Author

Ben Sergentanis

## Description

Demonstrates SmoothRandomGenerator module by modulating an oscillator's pitch.