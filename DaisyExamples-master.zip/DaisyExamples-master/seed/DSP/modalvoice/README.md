# ModalVoice Example

## Author

Ben Sergentanis

## Description

Demonstrates ModalVoice with parameter modulation.