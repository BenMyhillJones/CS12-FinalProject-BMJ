# Phaser Example

## Author

Ben Sergentanis

## Description

Demonstrates the phaser effect on a simple bassline.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/seed/phaser)
