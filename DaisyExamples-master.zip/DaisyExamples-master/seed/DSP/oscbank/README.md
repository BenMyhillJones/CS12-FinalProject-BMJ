# Oscillator Bank Example

Demonstrates Oscillator Bank module by generating chord stabs.

## Author

Ben Sergentanis