# Tremolo Example

## Author

Ben Sergentanis

## Description

Tremolo Module example. Randomlty modulates rate and depth.