# Osc

## Author

Shensley

## Description

Simple oscillator for daisy seed. Has button triggered envelope and knob controlled pitch.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/seed/Osc)

## Breadboard

<img src="https://raw.githubusercontent.com/electro-smith/DaisyExamples/master/seed/Osc/resources/Osc_bb.png" alt="Osc_bb.png" style="width: 100%;"/>

## Schematic  

<img src="https://raw.githubusercontent.com/electro-smith/DaisyExamples/master/seed/Osc/resources/Osc_schem.png" alt="Osc_schem.png" style="width: 100%;"/>

