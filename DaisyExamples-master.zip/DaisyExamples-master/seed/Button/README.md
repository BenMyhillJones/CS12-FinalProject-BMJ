# Button


## Author

Shensley

## Description

Turns on the seed's onboard LED as long as a button is held.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/seed/Button)

## Breadboard

<img src="https://raw.githubusercontent.com/electro-smith/DaisyExamples/master/seed/Button/resources/Button_bb.png" alt="Button_bb.png" style="width: 100%;"/>

## Schematic  

<img src="https://raw.githubusercontent.com/electro-smith/DaisyExamples/master/seed/Button/resources/Button_schem.png" alt="Button_schem.png" style="width: 100%;"/>
