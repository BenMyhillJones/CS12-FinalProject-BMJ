# Daisy Patch SM

Daisy Patch Submodule for use in custom eurorack modules and other audio hardware.  

## Getting Started
Getting started with the Patch SM? Check out the Getting Started examples!  
These are designed for the complete C++ beginner to get you writing audio code in no time!  