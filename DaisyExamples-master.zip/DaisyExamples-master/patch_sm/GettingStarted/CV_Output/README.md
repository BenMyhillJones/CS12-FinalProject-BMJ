# CV_Output

## Author

beserge

## Description

Simple ramp wave LFO to demonstrate CV Out.
For help connecting the CV output jack, refer to figure 1.9 in the [Patch SM Datasheet](https://github.com/electro-smith/DaisyPatchSM/blob/main/doc/datasheet/ES_Patch_SM_datasheet_v1.0.pdf).  
## Controls

| Pin Name | Pin Location | Function |
| --- | --- | --- |
| CV Out 1 | C10 | LFO Out |