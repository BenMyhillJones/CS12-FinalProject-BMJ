# Gate_In

## Author

beserge

## Description

Set the onboard led based on the gate input.
For help connecting the Gate Input jack, refer to figure 1.4 in the [Patch SM Datasheet](https://github.com/electro-smith/DaisyPatchSM/blob/main/doc/datasheet/ES_Patch_SM_datasheet_v1.0.pdf).  

## Controls

| Pin Name | Pin Location | Function |
| --- | --- | --- |
| Gate In 1 | B10 | Gate In |