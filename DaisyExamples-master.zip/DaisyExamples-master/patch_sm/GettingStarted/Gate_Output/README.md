# Gate_Output

## Author

beserge

## Description

Toggle Gate Out 1 four times a second.
For help connecting the gate output jack, refer to figure 1.10 in the [Patch SM Datasheet](https://github.com/electro-smith/DaisyPatchSM/blob/main/doc/datasheet/ES_Patch_SM_datasheet_v1.0.pdf).  

## Controls

| Pin Name | Pin Location | Function |
| --- | --- | --- |
| Gate Out 1 | B5 | Gate Out |