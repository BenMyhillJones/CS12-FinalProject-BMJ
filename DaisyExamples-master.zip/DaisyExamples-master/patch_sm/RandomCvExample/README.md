# RandomCvExample

This example demonstrates basic usage of the CV Outputs on the Daisy Patch SM.

Both CV outputs will output the same random voltage.

## Controls

None
