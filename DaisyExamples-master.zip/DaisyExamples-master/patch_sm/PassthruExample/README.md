# PassthruExample

This is a simple example of passing audio input through the Daisy Patch SM.

This is a great starting point for new projects using this board.

To use this project as a template for your own project you can use the following helper.py command:

```bash
./helper.py copy MyProjects/MyAwesomeNewProject --source patch_sm/PassthruExample
```

## Controls

None
