# Legio

Examples for the Noise Engineering Legio platform.

## Features

- Stereo Audio Input
- Stereo Audio Output
- 2x Knobs
- 2x CVs
- 1x 1v/8va input
- 1x Gate
- 2x 3-position toggles
- 1x Encoder /w button
- 2x RGB LEDs

