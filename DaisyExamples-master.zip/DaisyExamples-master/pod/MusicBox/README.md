# Music Box

## Author

Shensley


## Description
Generate random melodies.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/pod/MusicBox)

## Controls
| Control | Description | Comment |
| --- | --- | --- |
| Button 1 | Trigger Envelope | Selects new random note |
| Knob 1 | Decay Time |  |
| Knob 2 | Reverb Time |  |





