# Encoder

## Author

Shensley

## Pod Encoder
Simple example for Daisy Pod showing Encoder use.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/pod/Encoder)

## Controls
| Control | Description | Comment |
| --- | --- | --- |
| Encoder | Led Color | Turn to set color, press to turn off |






