# Midi

## Author

Shensley

## Description
Midi Controlled oscillator with resonant LPF.  

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/pod/Midi)

## Controls
| Control | Description |
| --- | --- |
| CC 1 | Filter Cutoff |
| CC 2 | Filter resonance |





