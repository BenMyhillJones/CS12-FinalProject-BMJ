# General Function Test

## Author

Shensley

## General Function Test

Vegas mode on the LEDs, while all controls' data are sent out via USB.

[Source Code](https://github.com/electro-smith/DaisyExamples/tree/master/petal/GeneralFunctionTest)

## TODO

* Add Encoder Increment checking as this isn't there, and wasn't idiomatic with either of the test loops.
