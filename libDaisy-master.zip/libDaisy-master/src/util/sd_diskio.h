#pragma once
#ifndef DSY_SD_DISKIO_H
#define DSY_SD_DISKIO_H
#ifdef __cplusplus
extern "C"
{
#endif

#include "util/bsp_sd_diskio.h"

    extern const Diskio_drvTypeDef SD_Driver; /**< & */

#ifdef __cplusplus
}
#endif

#endif
