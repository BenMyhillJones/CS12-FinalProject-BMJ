#pragma once
#ifndef DSY_VERSION_H
#define DSY_VERSION_H

#define LIBDAISY_VER_MAJ 4
#define LIBDAISY_VER_MIN 0
#define LIBDAISY_VER_PATCH 0

#endif
